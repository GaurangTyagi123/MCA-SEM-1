#include "basic_operations.h"
#include <cstddef>

/*
 Objective: To find the successor of the input number
 Params : n (size_t)
 return : n+1 (size_t)
 side-effect : none
 */

size_t succ(size_t n)
{
    return ++n;
}

/*
 Objective: Helper function for predecessor
 Params : target (size_t) current (size_t)
 return : n-1 (size_t)
 side-effect : none
 base-case : predHelper(target,target-1) -> target-1
 recursive-call : predHelper(target,current) -> predHelper(target,current + 1)
 approach : add 1 to current until it is not equal to the target
            then return current
 */

size_t predHelper(size_t target, size_t current)
{
    if (succ(current) == target)
        return current;
    return predHelper(target, succ(current));
}
/*
 Objective: To find the predecessor of the input number
 Params : n (size_t)
 return : n-1 (size_t)
 side-effect : none
 */
size_t pred(size_t n)
{
    // If the input number is 0 then return 0
    if (n == 0)
        return 0;

    // call the helper function
    return predHelper(n, 0);
}

/*
 Objective: To find the sum of two given numbers using pred and succ functions
 Params : n (size_t) m (size_t)
 return : m + n (size_t)
 side-effect : none
 base-case : sum(m+n,0) -> m+n
 recursive-call : sum(n,m) -> sum(n++,m--)
 */

size_t sum(size_t n, size_t m)
{
    // Approach : if m is 0 then return n
    //            else call sum on n+1 and m-1 (this will add 1 m times to n)
    if (!m)
    {
        return n;
    }
    else
    {
        return sum(succ(n), pred(m));
    }
}

/*
 Objective: To find the difference between two given numbers using pred and succ functions
 Params : n (size_t) m (size_t)
 Pre-condition : n,m are non-negative
 return : n - m (size_t)
 side-effect : none
 base-case : minus(n-m) -> m+n
 recursive-call : minus(n-m) -> minus(--n,--m)
 */
size_t minus(size_t n, size_t m)
{
    // Approach: if m is 0 then return n
    //           else call minus on n-1 and m-1
    if (!m)
    {
        return n;
    }
    else
    {
        return minus(pred(n), pred(m));
    }
}
/*
 Objective: To find the greatest common divisor of two given numbers
 Params : n (size_t) m (size_t)
 Pre-condition : n,m are non-negative
 return : gcd(m,n) (size_t)
 side-effect : none
 base-case : gcd(n,n)->n || gcd(m,m)->m
 recursive-call : gcd(n,m)->gcd(minus(n,m),m) if n > m
                  gcd(n,m)->gcd(n,minus(m,n)) if n < m
 */
size_t gcd(size_t n, size_t m)
{
    // Approach : If n and m are equal then return any one of them
    //            If n > m then call gcd on n-m and m
    //            If n < m then call gcd on n and m-n
    if (n == m)
        return n;
    else if (n > m)
        return gcd(minus(n, m), m);
    else
        return gcd(n, minus(m, n));
}