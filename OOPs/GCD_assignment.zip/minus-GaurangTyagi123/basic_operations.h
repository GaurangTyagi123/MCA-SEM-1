#ifndef BASIC_OPERATIONS_H
#define BASIC_OPERATIONS_H
#include <cstddef>

size_t succ(size_t);
size_t predHelper(size_t target, size_t current);
size_t pred(size_t);
size_t sum(size_t);
size_t minus(size_t);
size_t gcd(size_t, size_t);

#endif