#include <iostream>
#include "basic_operations.cpp"

int main()
{
    // declare variables to hold the two numbers comming as input from the user
    size_t num1, num2;

    // take first number as input and store it in num1
    std::cout << "Enter a non-negative number : ";
    std::cin >> num1;

    // take second number as input and store it in num2
    std::cout << "Enter a non-negative number : ";
    std::cin >> num2;

    // call gcd with num1 and num2 as arguments and store the result in result
    size_t result = gcd(num1, num2);

    // display the result on the console
    std::cout << "Greatest Common Divisor of " << num1 << " and " << num2 << " is: " << result << std::endl;

    return 0;
}